// // Create and Deploy Your First Cloud Functions
// // https://firebase.google.com/docs/functions/write-firebase-functions
//
// exports.helloWorld = functions.https.onRequest((request, response) => {
//  response.send("Hello from Firebase!");
// });
const functions = require('firebase-functions');
const firebase = require('firebase-admin');
const express = require('express');
const engines = require('consolidate');
const ejs = require('ejs');
const fs = require('fs');

const app = express();
const path = require('path');
const router = express.Router();

var Youtube = require('youtube-node');
var youtube = new Youtube();
var searchWord = '강아지'; //검색어
var limit = 10; //출력 갯수

//API 키 입력
youtube.setKey('AIzaSyDSvj554HNQskgqD2PEzXfs-nVOIgEc5XA'); 

//검색 옵션 시작
youtube.addParam('order', 'rating'); //평점 순으로 정렬
youtube.addParam('type', 'video'); //평점 순으로 정렬
youtube.addParam('videoLicense', 'creativeCommon'); // 크리에이티브 커먼즈 아이템만 불러옴
//// 검색 옵션 끝

youtube.search(searchWord, limit, function (err, result) { // 검색 실행
    if (err) { console.log(err); return; } // 에러일 경우 에러공지하고 빠져나감

    console.log(JSON.stringify(result, null, 2)); // 받아온 전체 리스트 출력

    var items = result["items"]; // 결과 중 items 항목만 가져옴
    for (var i in items) { 
        var it = items[i];
        var title = it["snippet"]["title"];
        var video_id = it["id"]["videoId"];
        var url = "https://www.youtube.com/watch?v=" + video_id;
        console.log("제목 : " + title);
        console.log("URL : " + url);
        console.log("-----------");
    }
});

var firebaseConfig = {
    apiKey: "api-key",
    authDomain: "choice-node.firebaseapp.com",
    databaseURL: "https://choice-node.firebaseio.com",
    projectId: "choice-node",
    storageBucket: "choice-node.appspot.com",
    messagingSenderId: "sender-id",
  };


app.set('view engine','ejs');
app.set('views', path.join(__dirname, 'views'));

router.route('/car_list/new').get((req,res)=>{
    console.log('/car_list/new 요청 들어옴');
    var cars = [{name:'SM3',price:2000,year:1999,company:'SAMSUNG'},
    {name:'SM9',price:6000,year:2013,company:'SAMSUNG'}];
    res.app.render('car_list',{cars:cars}, (err,html)=>{
        res.end(html);
    })
    //res.writeHead(200, {"content-type":"text/html;charset=utf8"});
    //res.end('<h1>새로운 방식</h1>');
});

router.route('/youtube').get((req,res)=>{
    console.log('/youtube 요청 들어옴');
    var cars = [{name:'aaa',price:2000,year:1999,company:'SAMSUNG'},
    {name:'bbb',price:6000,year:2013,company:'SAMSUNG'}];
    res.app.render('youtube',{cars:cars}, (err,html)=>{
        res.end(html);
    });

    youtube.search(searchWord, limit, function (err, result) { // 검색 실행
        if (err) { console.log(err); return; } // 에러일 경우 에러공지하고 빠져나감
    
        console.log(JSON.stringify(result, null, 2)); // 받아온 전체 리스트 출력
    
        var items = result["items"]; // 결과 중 items 항목만 가져옴
        for (var i in items) { 
            var it = items[i];
            var title = it["snippet"]["title"];
            var video_id = it["id"]["videoId"];
            var url = "https://www.youtube.com/watch?v=" + video_id;
            console.log("제목 : " + title);
            console.log("URL : " + url);
            console.log("-----------");
        }
    });
    //res.writeHead(200, {"content-type":"text/html;charset=utf8"});
    //res.end('<h1>새로운 방식</h1>');
});

app.get('/car_list/old', (request, response) => {
    response.set('Cache-Control', 'public, max-age=300, s-maxage=600');

    fs.readFile('./views/car_list.ejs', 'utf8', function(error, html) {
        response.writeHead(200, {'Content-Type':'text/html'});
        response.end(ejs.render(html,{cars:[{name:'SM3',price:2000,year:1999,company:'SAMSUNG'},{name:'SM9',price:6000,year:2013,company:'SAMSUNG'}]}));
    })   
});

app.use('/', router);

exports.app = functions.https.onRequest(app);